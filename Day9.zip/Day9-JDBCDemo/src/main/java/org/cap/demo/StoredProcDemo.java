package org.cap.demo;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Types;

public class StoredProcDemo {

	public static void main(String[] args) {
Connection con=null;
		
		try {
			//Loaded Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			
			//Establish connection
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb",
					"root", "admin");
			
			int empId=123;
			
			CallableStatement callableStatement=con.prepareCall("call findEmployee(?,?,?)");
			callableStatement.setInt(1,empId);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.NUMERIC);
			callableStatement.execute();
			
			String firstName= callableStatement.getString(2);
			BigDecimal salary=callableStatement.getBigDecimal(3);
			
			
			System.out.println("FirstName:" + firstName +"\n" 
					+"salary" + salary.doubleValue());

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
