package org.cap.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FetchEmployee {

	public static void main(String[] args) {
Connection con=null;
		
		try {
			//Loaded Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			
			//Establish connection
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb",
					"root", "admin");

			String sql="select * from employee";
			PreparedStatement pst=con.prepareStatement(sql);
			
			
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				//rs.getInt(1);
				int empid=rs.getInt("empid");
				String firstName=rs.getString(2);
				String lastName=rs.getString("lastName");
				double salary=rs.getDouble(4);
				
				System.out.println(empid + "\t" + firstName +"\t" + lastName + "\t" 
						+salary);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
