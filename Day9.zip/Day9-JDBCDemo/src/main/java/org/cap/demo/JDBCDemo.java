package org.cap.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDemo {

	public static void main(String[] args) {
		Connection con=null;
		
		try {
			//Loaded Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			
			//Establish connection
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb",
					"root", "admin");
			
			//Create statement
			//Statement statement=con.createStatement();
			
			//String sql="insert into employee values(?,?,?,?)";
			//String sql="delete from employee where empid=?";
			String sql="update employee set salary=?,firstname=? where empid=?";
			
			PreparedStatement preparedStatement=con.prepareStatement(sql);
			int empid=123;
			String firstName="Mary";
			//String lastName="Clark";
			double salary=23000;
		
			preparedStatement.setDouble(1, salary);
			preparedStatement.setString(2, firstName);
			preparedStatement.setInt(3, empid);
			/*preparedStatement.setString(2, firstName);
			preparedStatement.setString(3, lastName);
			preparedStatement.setDouble(4, salary);*/
			int count=preparedStatement.executeUpdate();
			
			
			//Execute Query
			/*String sql="create table employee(empid int primary key,firstname varchar(15),"
					+ "lastName varchar(15),salary numeric(8,2))";
			
			boolean flag=statement.execute(sql);
			if(flag==false) {
				System.out.println("Table Created Successfully");
			}*/
			
			
			
			//String sql="insert into employee values(1001,'Tom','Jerry',23000)";
			
			//String sql="insert into employee values("+empid +",'"+firstName +"','"+lastName +"',"+salary+")"; 
			
			//int count=statement.executeUpdate(sql);
			if(count>0)
				System.out.println("Record Inserted.");
			else
				System.out.println("Record Insertion Error!");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
