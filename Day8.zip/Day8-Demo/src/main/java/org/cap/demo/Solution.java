package org.cap.demo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Solution {

	public static void main(String[] args) {
		Employee employee1=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee2=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee3=new Employee(2, "Tom", "Jack", 56000);
		Employee employee4=new Employee(2, "Tom", "Jack", 56000);
		Employee employee5=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee6=new Employee(3, "Kamal", "Singh", 34500);
		Employee employee7=new Employee(5, "Tom", "Jerry", 23000);
		Employee employee8=new Employee(7, "Tom", "Jerry", 23000);
		Employee employee9=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee10=new Employee(1, "Tom", "Jerry", 23000);
		
		//HashSet<Employee> hashSet=new HashSet<>();
		Set<Employee> hashSet=new TreeSet<>();
		hashSet.add(employee10);
		hashSet.add(employee9);
		hashSet.add(employee8);
		hashSet.add(employee7);
		hashSet.add(employee6);
		hashSet.add(employee5);
		hashSet.add(employee4);
		hashSet.add(employee3);
		hashSet.add(employee2);
		hashSet.add(employee1);
		
		Iterator<Employee> iterator= hashSet.iterator();
		while(iterator.hasNext())
			System.out.println(iterator.next());

	}

}
