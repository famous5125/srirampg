package org.cap.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SortEmpFields {

	public static void main(String[] args) {
		Employee employee1=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee2=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee3=new Employee(2, "Tom", "Jack", 56000);
		Employee employee4=new Employee(2, "Tom", "Jack", 56000);
		Employee employee5=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee6=new Employee(3, "Kamal", "Singh", 34500);
		Employee employee7=new Employee(5, "Tom", "Jerry", 23000);
		Employee employee8=new Employee(7, "Tom", "Jerry", 23000);
		Employee employee9=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee10=new Employee(1, "Tom", "Jerry", 23000);
		
		List<Employee> employees=new ArrayList<>();
		
		employees.add(employee10);
		employees.add(employee9);
		employees.add(employee8);
		employees.add(employee7);
		employees.add(employee6);
		employees.add(employee5);
		employees.add(employee4);
		employees.add(employee3);
		employees.add(employee2);
		employees.add(employee1);
		
		Collections.sort(employees,new SortBySalary());
		
		Comparator<Employee> sortByLastName=new Comparator<Employee>() {

			@Override
			public int compare(Employee emp1, Employee emp2) {
				if(emp1.getLastName().compareTo(emp2.getLastName())>0)
					return 1;
				else if(emp1.getLastName().compareTo(emp2.getLastName())<0)
					return -1;
					else
						return 0;
			}
		};
		
		Collections.sort(employees,sortByLastName);
		
		Iterator<Employee> iterator=employees.iterator();
		while(iterator.hasNext())
			System.out.println(iterator.next());
		

	}

}
