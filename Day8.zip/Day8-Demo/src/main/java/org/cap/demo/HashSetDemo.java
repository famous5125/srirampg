package org.cap.demo;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class HashSetDemo {

	public static void main(String[] args) {
	
		//HashSet<String> hashSet=new HashSet<>();
		//Set<String> hashSet=new HashSet<>();
		//Collection<String> hashSet=new HashSet<>();
		
		Set<String> hashSet=new LinkedHashSet<>();
		
		hashSet.add("One");
		hashSet.add("Two");
		hashSet.add("One");
		hashSet.add(null);
		hashSet.add("Three");
		hashSet.add("One");
		hashSet.add("Four");
		hashSet.add("One");
		hashSet.add(null);
		System.out.println(hashSet);
		
		Iterator<String> iterator= hashSet.iterator();
		while(iterator.hasNext())
			System.out.println(iterator.next());

		//hashSet.
		
	}

}
