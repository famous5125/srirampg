package org.cap.demo;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TestClass {

	public static void main(String[] args) {
		Set<String> names=new TreeSet<>();
		names.add("Tom");
		names.add("Tom");
		names.add("ani");
		//names.add(null);
		names.add("Anil");
		names.add("Anita");
		names.add("Jessi");
		//names.add(null);
		names.add("mark");
		names.add("Simson");
		
		Iterator<String> iterator= names.iterator();
		
		while(iterator.hasNext())
			System.out.println(iterator.next());

	}

}
