package org.cap.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		
		//Vector<Integer> vector=new Vector<>(30);
		//Vector<Integer> vector=new Vector<>(30,10);
		List<Integer> vector=new ArrayList<>();
		vector.add(12);
		vector.add(null);
		vector.add(90);
		vector.add(12);
		vector.add(1290);
		vector.add(123);
		vector.add(null);
		vector.add(12);
		
		System.out.println(vector);
		
		Collections.synchronizedList(vector);
		
		
		/*Enumeration<Integer> enumeration= vector.elements();
		while(enumeration.hasMoreElements()) {
			Integer num=enumeration.nextElement();
			System.out.println(num);
		}
		*/
		
		

	}

}
