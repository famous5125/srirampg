package org.cap.demo;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> list=new LinkedList<String>();
		
		list.add("Tom");
		list.add(null);
		list.add("Jerry");
		list.add("Kamal");
		list.add("Singh");
		list.add("Kamal");
		list.add("Kamal");
		list.add(null);
		list.add("Jack");
		list.add(null);
		list.add("Jack");
		
		
		Iterator<String> iterator=list.iterator();

		while(iterator.hasNext()) {
			String str=iterator.next();
			System.out.print(str + " -->");
			
		}
		
		System.out.println();
		
		//list.ad
		list.offer("ONe");
		System.out.println(list);
		String str=list.peek();
		System.out.println(str);
		
		System.out.println(list);
		
		String str1=list.poll();
		System.out.println(str1);
		System.out.println(list);
		list.set(0, "Thomson");
		System.out.println(list);
		System.out.println(list.pop());
		list.push("Two");
		System.out.println(list);
		
	}

}
