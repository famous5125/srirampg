package org.cap.mapdemo;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MainClass {

	public static void main(String[] args) {
		//Map<Integer, String> maps=new HashMap<>();
		//HashMap<Integer, String> maps=new HashMap<>();
		//Map<Integer, String> maps=new Hashtable<>();
		
		//Map<Integer, String> maps=new LinkedHashMap<>();
		
		Map<Integer, String> maps=new TreeMap<>();
		
		maps.put(12, "Tom");
		maps.put(1, "Jack");
		maps.put(12, "Tom");
		maps.put(123, "Jerry");
		maps.put(1001, "Emi");
		maps.put(190, null);
		//maps.put(null, null);
		/*maps.put(null, "ONe");
		maps.put(null, "Two");
		maps.put(null, null);*/
		
		System.out.println(maps);
		
		
		
		Collections.synchronizedMap(maps);
		
		Set<Integer> keys= maps.keySet();
		
		Iterator<Integer> iterator=keys.iterator();
		while(iterator.hasNext()) {
			Integer key=iterator.next();
			System.out.println(key + "-->" + maps.get(key));
		}
		
	}

}
