package org.cap.mapdemo;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.cap.demo.Employee;

public class TestClass {

	public static void main(String[] args) {
		TreeMap<Employee, String> maps=new TreeMap<>();
		
		Employee employee1=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee2=new Employee(1, "Tom", "Jerry", 23000);
		Employee employee3=new Employee(2, "Tom", "Jack", 56000);
		Employee employee4=new Employee(2, "Tom", "Jack", 56000);
		Employee employee5=new Employee(1, "Tom", "Jerry", 23000);
		
		maps.put(employee5, "Hello Tom");
		maps.put(employee4, "Hello Jerry");
		maps.put(employee3, "Hello Tom");
		maps.put(employee2, "Hello Tom");
		maps.put(employee1, "Hello Tom");
		
		
		Set<Employee> keys=maps.keySet();
		
		Iterator<Employee> iterator= keys.iterator();
		while(iterator.hasNext())
		{
			Employee employee=iterator.next();
			System.out.println(employee + "-->" + maps.get(employee));
		}
		
		
	}

}
