package org.cap.enumdemo;

public enum Size {
	SMALL(10,16),LARGE(21,25),MEDIUM(17,20),EXTRALARGE(26,30);
	
	private int minValue;
	private int maxValue;

	private Size(int minValue,int maxValue) {
		this.minValue=minValue;
		this.maxValue=maxValue;
	}
	
	public int getMinValue() {
		return this.minValue;
	}
	
	public int getMaxValue() {
		return this.maxValue;
	}
	
}
