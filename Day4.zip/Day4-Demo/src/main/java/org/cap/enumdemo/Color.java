package org.cap.enumdemo;

public interface Color {
	
	public void fillColor();
	
	public interface WaxColor{
		public void fillWaxColor();
		
	}

}
