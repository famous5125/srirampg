package org.cap.enumdemo;

public class MyClass implements Color ,Color.WaxColor {

	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	public void fillWaxColor() {
		// TODO Auto-generated method stub
		
	}

}
