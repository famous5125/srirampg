package org.cap.enumdemo;

public class OuterClass {
	private int num=100;
	String name="OuterClass";
	
	class Inner{
		private int ans=10;
		String myName="innerClass";
		
		
		public void show() {
			System.out.println("Answer:" + ans + "\nName:" + myName) ;
			System.out.println("Num:" + num + "\nName:" + name);
		}
	}
	
	
	public void display() {
		System.out.println("Num:" + num + "\nName:" + name);
		Inner obj=new Inner();
		obj.show();
	}

	
	
	public static void main(String[] args) {
		OuterClass class1=new OuterClass();
		class1.display();
		
		
		//Inner class object
		OuterClass.Inner inner=class1.new Inner();
		inner.show();
		
	}
}
