package org.cap.enumdemo;

public class Demo {
	
	public void display() {
		System.out.println("Demo Class Display!");
	}

}
