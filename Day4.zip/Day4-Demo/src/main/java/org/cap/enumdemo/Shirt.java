package org.cap.enumdemo;

public class Shirt {
	
	private String brandName;
	private double price;
	private Size size;
	
	/*@Override
	public String toString() {
		return "[Shirt: BrandName => " + this.brandName +" , Size => " + this.size 
				+", Price => " + this.price + "]" ;
	}*/
	
	@Override
	public String toString() {
		return "Shirt [brandName=" + brandName + ", price=" + price + ", "
				+ "size=" + size+"=>"+this.size.getMinValue()+"-"+this.size.getMaxValue() + "]";
		
	}




	public static void main(String...args) {
		Shirt shirt=new Shirt();
		shirt.brandName="POLO";
		shirt.size=Size.LARGE;
		shirt.price=390.56;
		
		System.out.println(shirt);
	}
	

}
