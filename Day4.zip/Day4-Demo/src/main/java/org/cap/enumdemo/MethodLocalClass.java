package org.cap.enumdemo;

public class MethodLocalClass {

	
	private int num=100;
	
	public void display() {
		final String name="OuterClass";
		
		
		//Method localinner class
		class InnerClass{
			float pi=3.14f;
			String str="Welcome";
			
			public void show() {
				System.out.println("PI:" + pi + "  String:" + str);
				
				System.out.println("Num:" + num);
				System.out.println("name:" + name);
			}
		}
		
		
		InnerClass innerClass=new InnerClass();
		innerClass.show();
		
	}
	
	
	public static void main(String[] args) {
		
		MethodLocalClass obj=new MethodLocalClass();
		obj.display();
		
	}

}
