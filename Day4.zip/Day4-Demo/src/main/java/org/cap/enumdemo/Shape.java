package org.cap.enumdemo;

abstract public class Shape {

	
	abstract public void draw();
}
