package org.cap.enumdemo;

public class TestClass {

	public static void main(String[] args) {
		
		Shape shape=new Shape() {
			
			@Override
			public void draw() {
			System.out.println("Draw Shape");
				
			}
		};
		
		Shape circle=new Shape() {
			
			@Override
			public void draw() {
			System.out.println("Draw Circle");
				
			}
		};

		
		shape.draw();
		circle.draw();
	}

}
