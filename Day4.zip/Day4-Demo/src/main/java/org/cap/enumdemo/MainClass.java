package org.cap.enumdemo;

public class MainClass {

	public static void main(String[] args) {
		Demo  demo=new Demo();
		demo.display();
		
		Demo obj=new Demo() {
			@Override
			public void display() {
				System.out.println("Demo Class Implemented instantaly!");
			}
			
		};

		
		obj.display();
		
		
		
		Color color=new Color() {
			
			public void fillColor() {
				System.out.println("Fill my Shape");
				
			}
		};
		color.fillColor();
		
	}

}
