package org.cap.enumdemo;

public class StaticClsDemo {
	private static int num=100;
	private static int ans=1000;
	
	
	static class MyStaticInnerClass{
		int value=10;
		int mynum=200;
		
		/*
		public static void show() {
			//System.out.println("Value:" + this.value);
			//System.out.println("Number:" + this.mynum);
			//System.out.println("Outer Instance Member:" + num);
			
			System.out.println("Outer Static Member:" + ans);
		}
		*/
		
		public  void show() {
			System.out.println("Value:" + this.value);
			System.out.println("Number:" + this.mynum);
			//System.out.println("Outer Instance Member:" + num);
			
			System.out.println("Outer Static Member:" + ans);
		}
		
	}
	

	public static void main(String[] args) {
		
		
		StaticClsDemo obj=new StaticClsDemo();
		
		StaticClsDemo.MyStaticInnerClass staticobj
				=new StaticClsDemo.MyStaticInnerClass();
		staticobj.show();
		
	}

}
