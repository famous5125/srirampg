package org.cap.demo;

public class Validation {

	public static void main(String[] args) {
	
		String mobile="1234567890";
		String accountNo="1234567-ABCD";
		
		System.out.println(mobile.matches("\\d{10}"));
		System.out.println(mobile.matches("[0-9]{10}"));
		
		if(accountNo.matches("\\d{7}-[A-Z]{4}")) {
			System.out.println("Valid Account Number");
			
		}else {
			System.out.println("Invalid Account Number");
		}
		
	}

}
