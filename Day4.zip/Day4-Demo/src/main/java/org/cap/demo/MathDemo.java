package org.cap.demo;

public class MathDemo {

	public static void main(String[] args) {
		double num=23.456456;
		
		System.out.println(Math.round(num));
		System.out.println(Math.floor(num));
		System.out.println(Math.ceil(num));
		
		System.out.println("Min Int :" + Integer.MIN_VALUE);
		System.out.println("Max Int :" + Integer.MAX_VALUE);
		
		Integer mynum=10;
		Integer mynum1=new Integer(100);
		
		int ans=mynum+mynum1;
		
		System.out.println(ans);
		
		
		String str="1000";
		int number=Integer.parseInt(str);
		

	}

}
