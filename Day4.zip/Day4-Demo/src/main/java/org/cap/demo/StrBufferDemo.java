package org.cap.demo;

public class StrBufferDemo {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer(20);
		
		sb.append("Tom");
		//StringBuffer sb=new StringBuffer("tom");
		
		System.out.println("Length:" + sb.length());
		System.out.println("Length:" + sb.capacity());
		
		sb.insert(2, "Hello");
		System.out.println("Value:" + sb);
		
		System.out.println("Value:" + sb.reverse());
		System.out.println("Value:" + sb);
	}

}
