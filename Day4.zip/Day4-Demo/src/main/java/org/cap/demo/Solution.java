package org.cap.demo;

public class Solution {

	public static void main(String[] args) {
		String str="Tom";
		String name=new String("Tom");
		
		String str1="Tom";
		String myName="Tom";
		
		//System.out.println(str.hashCode());
		//System.out.println(name.hashCode());

		System.out.println("Equals:" + str.equals(name));
		System.out.println("Equals:" + (str==name));
		
		//System.out.println("Equals:" + str.equals(name));
		System.out.println("Equals:" + (str==str1));
		str=str+" Jerry";
		
	}

}
