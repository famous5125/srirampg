package org.cap.demo;

public class MyDemo {

	public static void main(String[] args) {
		String str="Tom Jerry";
		String greet="Hello!";
		
		System.out.println("Chat At:" + str.charAt(4));
		System.out.println("Concat:"  + greet.concat(str));
		System.out.println("Greet:" + greet);
		System.out.println("Str:" + str);
		String str1="tom jerry";
		System.out.println("Compare:"  +str.compareTo(greet));
		System.out.println("Compare:"  +str.compareToIgnoreCase(str1));
		System.out.println("Contains:" +str.contains("am"));
		System.out.println("Endswith:" +str.endsWith("Jerry"));
		byte[] myChars=str.getBytes();
		
		for(byte ch:myChars) {
			System.out.println((char)ch);
		}
		
		System.out.println("HashCode:" + str.hashCode());
		System.out.println("Index:" + str.indexOf("rry"));
		System.out.println("Index:" + str.indexOf("r",7));
		String name="";
		System.out.println("Is Empty:"+name.isEmpty());
		
		System.out.println("Last Index of:" + str.lastIndexOf("r"));
		System.out.println("Length:" + str.length());
		
		System.out.println("Replace:" + str.replace("Jerry","Jhon"));
		
		
		String myStr="Welcome To Java Session! Hello All!";
		String[] strs= myStr.split("!");
		
		for(String s:strs)
			System.out.println(s);
		
		System.out.println("SubString:" + str.substring(4,7));
		System.out.println("LowerCase: " + str.toLowerCase());
		System.out.println("LowerCase: " + str.toUpperCase());
		
		str="      Tom Jerry         ";
		System.out.println("Length:" + str.length());
		System.out.println("Length:" + str.trim().length());
		
		System.out.println("Value Of:" );
	}

}
