package org.cap.dao;

import java.util.List;

import org.cap.pojo.Employee;
import org.cap.pojo.LoginPojo;

public interface LoginDao {
	public boolean validateLogin(LoginPojo login);
	public boolean addEmployee(Employee employee);
	public List<Employee> getAllEmployees();
	
	public boolean deleteEmployee(int employeeId);
}
