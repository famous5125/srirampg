package org.cap.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cap.pojo.Employee;
import org.cap.pojo.LoginPojo;

public class LoginDaoImpl implements LoginDao{

	public boolean validateLogin(LoginPojo login) {
		
		String sql="select * from usertable where "
				+ "username=? and userpassword=?";
		try {
			PreparedStatement pst=getMySqlConnection()
					.prepareStatement(sql);
			pst.setString(1,login.getUserName());
			pst.setString(2,login.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

	
	
	public Connection getMySqlConnection() {
		
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb",
					"root", "admin");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}



	public boolean addEmployee(Employee employee) {
		String sql="insert into employee(firstname,lastname,"
				+ "address,salary,city,gender,practice,empdoj) values"
				+ "(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=getMySqlConnection().prepareStatement(sql);
			pst.setString(1, employee.getFirstName());
			pst.setString(2, employee.getLastName());
			pst.setString(3, employee.getAddress());
			pst.setDouble(4, employee.getSalary());
			pst.setString(5, employee.getCity());
			pst.setString(6, employee.getGender());
			pst.setString(7, employee.getPractice());
			pst.setDate(8, new java.sql.Date(employee.getEmpDoj().getTime()));
			
			int count=pst.executeUpdate();
			if(count>0)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return false;
	}



	public List<Employee> getAllEmployees() {
		
		List<Employee> employees=new ArrayList<Employee>();
		
		String sql="select * from employee";
		try {
			PreparedStatement pst=getMySqlConnection().prepareStatement(sql);
			ResultSet rs= pst.executeQuery();
			
			while(rs.next()) {
				
				Employee employee=new Employee();
				employee.setEmpid(rs.getInt("empid"));
				employee.setFirstName(rs.getString("firstname"));
				employee.setLastName(rs.getString("lastname"));
				employee.setAddress(rs.getString("address"));
				employee.setCity(rs.getString("city"));
				employee.setGender(rs.getString("gender"));
				employee.setPractice(rs.getString("practice"));
				employee.setSalary(rs.getDouble("salary"));
				employee.setEmpDoj(rs.getDate("empdoj"));
				
				employees.add(employee);
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return employees;
	}



	public boolean deleteEmployee(int employeeId) {
		String sql="delete from employee where empid=?";
		
		try {
			PreparedStatement pst=getMySqlConnection().prepareStatement(sql);
			pst.setInt(1, employeeId);
			
			int count=pst.executeUpdate();
			if(count>0)
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
}
