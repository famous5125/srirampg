package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pojo.Employee;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;


public class ListAllEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String email=null;
	String companyName=null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletContext= config.getServletContext();
		email=servletContext.getInitParameter("cgEmail");
		companyName=config.getInitParameter("CompanyName");
		
	}


	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
	
	LoginService loginService=new LoginServiceImpl();
	List<Employee> employees=  loginService.getAllEmployees();
	
	PrintWriter out=response.getWriter();
	
	out.println("<html>"
			+ "<head>Employee List</head>"
			+ "<body>"
			+ "<table>"
			+ "<tr>"
			+ "<th>EmpId</th>"
			+ "<th>FirstName</th>"
			+ "<th>LastName</th>"
			+ "<th>Salary</th>"
			+ "<th>City</th>"
			+ "<th>Edit</th>"
			+ "</tr>");
	
	for(Employee emp:employees) {
		out.println("<tr>"
				+ "<td>" + emp.getEmpid() +"</td>"
				+ "<td>" + emp.getFirstName() +"</td>"
				+ "<td>" + emp.getLastName() +"</td>"
				+ "<td>" + emp.getSalary() +"</td>"
				+ "<td>" + emp.getCity() +"</td>"
				+ "<td>"
				+ "<a href='DeleteEmpServlet?employeeId="+emp.getEmpid()+"'>Delete</a> &nbsp;&nbsp;&nbsp;&nbsp;"
						+ "<a href='UpdateEmpServlet?employeeId="+emp.getEmpid()+"'>Update</a>"
								
						+ "</td>"
				+ "</tr>");
	}
	
	
	out.println("</table><br><br>"
			+ "<div style='width:400px;text-align:right;'> "+email+"</div>"
			+ "<div style='width:400px;text-align:right;'> "+companyName+"</div>"
			+ "</body>"
			+ "</html>");
	
	}

}
