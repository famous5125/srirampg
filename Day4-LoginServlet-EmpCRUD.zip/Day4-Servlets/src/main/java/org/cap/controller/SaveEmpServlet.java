package org.cap.controller;

import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pojo.Employee;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;


public class SaveEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String email=null;
	String companyName=null;
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletContext= config.getServletContext();
		email=servletContext.getInitParameter("cgEmail");
		
		companyName=config.getInitParameter("CompanyName");
		
		Enumeration<String> enums=servletContext.getInitParameterNames();
		
		while(enums.hasMoreElements())
			System.out.println("ParamName ->" + enums.nextElement());
		
	}




	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String empAddress=request.getParameter("empAddress");
		String empDoj=request.getParameter("empDoj");
		String city=request.getParameter("city");
		String salary=request.getParameter("salary");
		String gender=request.getParameter("gender");
		String[] practices=request.getParameterValues("practice");
		String practice="";
		for(String str:practices)
			practice+=str+",";
		
		//Employee POJO
		Employee employee=new Employee();
		employee.setFirstName(firstName);
		employee.setLastName(lastName);
		employee.setAddress(empAddress);
		
		System.out.println(empDoj);
		
		Date employeeDoj=new Date();
		int month=Integer.parseInt(empDoj.substring(5, 7));
		int date=Integer.parseInt(empDoj.substring(8, empDoj.length()));
		int year=Integer.parseInt(empDoj.substring(0, 4));
		
		System.out.println(year + "," + month +"," + date);
		
		employeeDoj.setDate(date);
		employeeDoj.setMonth(month);
		employeeDoj.setYear(year);
		
		employee.setEmpDoj(employeeDoj);
		
		employee.setCity(city);
		employee.setSalary(Double.parseDouble(salary));
		employee.setGender(gender);
		employee.setPractice(practice);
		//System.out.println(employee);
		System.out.println("Email Id:" + email);
		System.out.println("CompanyName:" + companyName);
		
		//insert into DB
		LoginService loginService=new LoginServiceImpl();
		boolean flag=loginService.addEmployee(employee);
		if(flag) {
			System.out.println("Record inserted.");
			request.getRequestDispatcher("pages/addEmployee.html")
				.include(request, response);
		}
		else
			System.out.println("Record insertion failure!");
	}

}
