package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;


public class DeleteEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		LoginService service=new LoginServiceImpl();
		
		int empid=Integer.parseInt(request.getParameter("employeeId"));
		boolean flag=service.deleteEmployee(empid);
		if(flag) {
			System.out.println("Employee Deleted.");
			request.getRequestDispatcher("ListAllEmpServlet")
			.forward(request, response);
		}else {
			System.out.println("Deletion error!.");
		}
		
	}

}
