package org.cap.service;

import java.util.List;

import org.cap.dao.LoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.pojo.Employee;
import org.cap.pojo.LoginPojo;

public class LoginServiceImpl implements LoginService {
	
	private LoginDao loginDao=new LoginDaoImpl();

	public boolean validateLogin(LoginPojo login) {
		/*if(login.getUserName().equals("tom") &&
				login.getUserPassword().equals("tom123"))
			return true;
		return false;*/
		
		return loginDao.validateLogin(login);
	}

	public boolean addEmployee(Employee employee) {
		
		return loginDao.addEmployee(employee);
	}

	public List<Employee> getAllEmployees() {
		return loginDao.getAllEmployees();
	}

	public boolean deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return loginDao.deleteEmployee(employeeId);
	}

}
