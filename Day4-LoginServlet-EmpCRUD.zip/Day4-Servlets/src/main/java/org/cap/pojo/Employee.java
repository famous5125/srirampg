package org.cap.pojo;

import java.util.Date;

public class Employee {
	private int empid;
	private String firstName;
	private String lastName;
	private double salary;
	private String address;
	private String city;
	private String gender;
	private String practice;
	private Date empDoj;
	
	public Employee() {
		
	}
	
	
	public Employee(int empid, String firstName, String lastName, double salary, String address, String city,
			String gender, String practice, Date empDoj) {
		super();
		this.empid = empid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.practice = practice;
		this.empDoj = empDoj;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPractice() {
		return practice;
	}
	public void setPractice(String practice) {
		this.practice = practice;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", address=" + address + ", city=" + city + ", gender=" + gender + ", practice=" + practice
				+ ", empDoj=" + empDoj + "]";
	}
	
	

}
