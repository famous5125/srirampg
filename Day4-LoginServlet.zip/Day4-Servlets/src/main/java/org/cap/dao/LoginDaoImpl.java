package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.pojo.LoginPojo;

public class LoginDaoImpl implements LoginDao{

	public boolean validateLogin(LoginPojo login) {
		
		String sql="select * from usertable where "
				+ "username=? and userpassword=?";
		try {
			PreparedStatement pst=getMySqlConnection()
					.prepareStatement(sql);
			pst.setString(1,login.getUserName());
			pst.setString(2,login.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

	
	
	public Connection getMySqlConnection() {
		
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb",
					"root", "admin");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
}
