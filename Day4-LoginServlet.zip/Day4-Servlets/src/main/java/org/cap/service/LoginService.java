package org.cap.service;

import org.cap.pojo.LoginPojo;

public interface LoginService {

	public boolean validateLogin(LoginPojo login);
}
