package org.cap.service;

import org.cap.dao.LoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.pojo.LoginPojo;

public class LoginServiceImpl implements LoginService {
	
	private LoginDao loginDao=new LoginDaoImpl();

	public boolean validateLogin(LoginPojo login) {
		/*if(login.getUserName().equals("tom") &&
				login.getUserPassword().equals("tom123"))
			return true;
		return false;*/
		
		return loginDao.validateLogin(login);
	}

}
