package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.pojo.LoginPojo;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upassword");
		
		//created POJO objected input
		LoginPojo login=new LoginPojo();
		login.setUserName(userName);
		login.setUserPassword(userPwd);
		
		
		//call service for login verification
		LoginService loginService=new LoginServiceImpl();
		
		if(loginService.validateLogin(login)) {
			response.sendRedirect("success.html");
		}else {
			response.sendRedirect("home.html");
		}
		
		/*if(userName.equals("tom") && userPwd.equals("tom123")) {
			response.sendRedirect("success.html");
		}else
		{
			response.sendRedirect("home.html");
		}*/
		
		}

}
