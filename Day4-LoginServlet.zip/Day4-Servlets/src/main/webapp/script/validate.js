function validate(){
	var userName=f1.uname.value;
	var userPwd=f1.upassword.value;
	var flag=true;
	if(userName==""||userName==null)
	{
		//alert("Please enter userName");
		document.getElementById('userErrMsg')
				.innerHTML="* Please enter userName";
		flag=false;
	}else if(userPwd==""||userPwd==null){
		
		document.getElementById('pwdErrMsg')
		.innerHTML="* Please enter user password";
		flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}