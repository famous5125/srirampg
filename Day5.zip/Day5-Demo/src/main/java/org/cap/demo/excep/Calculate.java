package org.cap.demo.excep;

public class Calculate {
	
	
	public void calculate() throws ArithmeticException, NumberFormatException, InvalidAgeException {
		int num1=34;
		String num2="0s";
		int age=12;
		int ans=0;
		
		if(age<18)
			throw new InvalidAgeException("Sorry Invalid Age!");
		
		ans=num1/Integer.parseInt(num2);
			System.out.println("My Answer processed");
		
		System.out.println("Answer:" + ans);
		
	}

}
