package org.cap.demo.assignment;

public class BootClass {

	public static void main(String[] args) {
		UserInteraction interaction=new UserInteraction();
		Employee employee=interaction.getEmployeeDetails();
		
		System.out.println(employee);

	}

}
