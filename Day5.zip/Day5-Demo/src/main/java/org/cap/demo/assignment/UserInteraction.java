package org.cap.demo.assignment;

import java.util.Scanner;

public class UserInteraction {
	
	Scanner scanner=new Scanner(System.in);
	
	public Employee getEmployeeDetails() {
		Employee employee=new Employee();
		boolean flag=false;
		
		do {
			System.out.println("Enter Employee FirstName:");
			String empFirstName=scanner.nextLine();
			
			if(isValidName(empFirstName)) {
				flag=true;
				employee.setFirstName(empFirstName);
			}
			
		}while(flag==false);
		
		
		
		flag=false;
		do {
			System.out.println("Enter Employee KinId");
			String kinId=scanner.next();
			
			if(isValidKinId(kinId)) {
				flag=true;
				employee.setkinId(kinId);
			}
			
		}while(flag==false);
		
		
		
		
		
		
		return employee;
	}
	
	
	public boolean isValidName(String name) {
		return name.matches("[a-zA-Z ]+");
	}
	
	public boolean isValidKinId(String kinId) {
		return kinId.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
		
	}
	
	
	public boolean isValidEmail(String email) {
		return email.matches("^[_A-Za-z0-9-\\\\+]+(\\\\.[_A-Za-z0-9-]+)*\r\n" + 
				"      @[A-Za-z0-9-]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$;");
	}
	
	

}
