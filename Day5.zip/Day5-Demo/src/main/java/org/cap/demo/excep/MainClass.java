package org.cap.demo.excep;

public class MainClass {

	public static void main(String[] args) {
		
		Calculate obj=new Calculate();
		try {
		obj.calculate();
		}catch (ArithmeticException e) {
			System.out.println("Exception caught: " + e.getMessage() );
		}catch (NumberFormatException e) {
			System.out.println("NumberFormatException caught: " + e.getMessage() );
		}catch (InvalidAgeException e) {
			System.out.println("InvalidAge exception: " + e.getMessage() );
		}
		
		
		System.out.println("Execution Completed");

	}

}
