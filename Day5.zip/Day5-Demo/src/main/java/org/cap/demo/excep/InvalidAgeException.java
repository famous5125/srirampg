package org.cap.demo.excep;

public class InvalidAgeException extends RuntimeException{
	
	public InvalidAgeException() {
		super("Age should be greater than 18!");
	}
	
	public InvalidAgeException(String msg) {
		super(msg);
	}
	
	/*@Override
	public String getMessage() {
		return "Age should be greater than 18!";
	}
*/
}
