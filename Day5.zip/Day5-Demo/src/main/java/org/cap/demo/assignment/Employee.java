package org.cap.demo.assignment;

public class Employee {
	
	private String kinId;
	private String firstName;
	private String lastName;
	private String date_of_birth;
	private String date_of_joining;
	private double salary;
	private String emailId;
	private String mobileNo;
	
	public Employee() {
		
	}
	
	public Employee(String kinId, String firstName, String lastName, String date_of_birth, String date_of_joining,
			double salary, String emailId, String mobileNo) {
		super();
		this.kinId = kinId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.date_of_birth = date_of_birth;
		this.date_of_joining = date_of_joining;
		this.salary = salary;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
	}
	public String getkinId() {
		return kinId;
	}
	public void setkinId(String kinId) {
		this.kinId = kinId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getDate_of_joining() {
		return date_of_joining;
	}
	public void setDate_of_joining(String date_of_joining) {
		this.date_of_joining = date_of_joining;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Employee [kinId=" + kinId + ", firstName=" + firstName + ", lastName=" + lastName + ", date_of_birth="
				+ date_of_birth + ", date_of_joining=" + date_of_joining + ", salary=" + salary + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + "]";
	}
	
	
	

}
