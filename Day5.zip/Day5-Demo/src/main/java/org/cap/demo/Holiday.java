package org.cap.demo;

public enum Holiday {

	SUN(1),MON(2),TUS(3),WED(4),THUR(5),FRI(6),SAT(7);
	
	private int value;
	
	private Holiday(int value) {
		this.value=value;
	}
	
	private int getValue() {
		return this.value;
	}
}
