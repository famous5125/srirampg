package org.cap.demo;

public class Shop {
	
	private int shopId;
	private String shopName;
	private String shopAddress;
	private Holiday holiday;
	
	public Shop() {
		
	}
	
	
	public Shop(int shopId, String shopName, String shopAddress, Holiday holiday) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.shopAddress = shopAddress;
		this.holiday = holiday;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopAddress() {
		return shopAddress;
	}
	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}
	public Holiday getHoliday() {
		return holiday;
	}
	public void setHoliday(Holiday holiday) {
		this.holiday = holiday;
	}
	
	
	
	
	/*@Override
	public boolean equals(Object obj) {
		Shop shop=(Shop)obj;
		
		if(this==obj)
			return true;
		else if(this==null || obj==null)
			return false;
		else if(this.shopId==shop.shopId) {
			if(this.shopName.compareToIgnoreCase(shop.shopName)==0) {
				if(this.shopAddress.compareToIgnoreCase(shop.shopAddress)==0) {
					if(this.holiday==shop.holiday){
						return true;
					}
					else {return false;}
				}
					else {return false;}
			}else {return false;}
		}else return false;
	}*/
			
	
	
	

	@Override
	public String toString() {
		return "Shop [shopId=" + shopId + ", shopName=" + shopName + ", shopAddress=" + shopAddress + ", holiday="
				+ holiday + "]";
	}


	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Shop other = (Shop) obj;
		if (holiday != other.holiday)
			return false;
		if (shopAddress == null) {
			if (other.shopAddress != null)
				return false;
		} else if (!shopAddress.equals(other.shopAddress))
			return false;
		if (shopId != other.shopId)
			return false;
		if (shopName == null) {
			if (other.shopName != null)
				return false;
		} else if (!shopName.equals(other.shopName))
			return false;
		return true;
	}
	
	
	
	

}
