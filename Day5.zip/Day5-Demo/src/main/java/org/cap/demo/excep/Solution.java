package org.cap.demo.excep;

public class Solution {

	public static void main(String[] args) {
		
		String num="1000";
		int num1=5000;
		int ans=0;
		
		try {
			ans=num1/Integer.parseInt(num);
			
				try {
				String n1="100";
				String n2="0";
				if(Integer.parseInt(n2)==0)
					throw new ArithmeticException("Hey! n2 is Zero! Sorry we can not process!");
				
				int result=Integer.parseInt(n1)/Integer.parseInt(n2);
				System.out.println("Result:" + result);
				}catch (NullPointerException e) {
					System.out.println("MyException:" );
					e.printStackTrace();
				}
			
			System.out.println("Nested Block completed");
			
		}/*catch (Exception e) {
			e.printStackTrace();
		}*/
		
	catch (ArithmeticException e) {
			e.printStackTrace();
		}catch (ClassCastException e) {
			System.out.println("number format exception:");
			e.printStackTrace();
		}catch (NumberFormatException e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("Finally Block execution");
		}
		
		
		
		System.out.println("Answer:" + ans);

	}

}
