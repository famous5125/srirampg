package org.cap.demo;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction interaction=new UserInteraction();
		
		//Shop shop=interaction.getShopDetails();
		
		//System.out.println(shop);
		
		Shop shop=new Shop(1, "ABC", "North Avvennue", Holiday.SAT);
		Shop shop1=new Shop(1, "ABC", "North Avvennue", Holiday.SAT);

		System.out.println("Equals:" + shop.equals(shop1));
		
	}

}
