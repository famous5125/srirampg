package org.cap.demo.excep;

public class Student {
	
	int age;
	
	public static void main(String[] args) {
		Student student=new Student();
		try {
		student.age=15;
		
		if(student.age<18)
			throw new InvalidAgeException();
		
		}/*catch (InvalidAgeException e) {
			System.out.println(e.getMessage());
		}*/catch (NullPointerException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("Execution Done!");
		
	}

}
