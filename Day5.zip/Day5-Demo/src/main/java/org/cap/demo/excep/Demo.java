package org.cap.demo.excep;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Demo {

	public static void main(String[] args) throws FileNotFoundException{
		int num1=34;
		String num2="0";
		
		int ans=0;
		
		try {
			File file=new File("greet.txt");
			FileInputStream fileInputStream=new FileInputStream(file);
			
			//throw new FileNotFoundException();
			
			if(num2.matches("[A-Za-z]+"))
				throw new NumberFormatException("Sorry! Your number has alphabets");
			
			int num=Integer.parseInt(num2);
			if(num==0)
				throw new ArithmeticException("Sorry! number can not be devided by zero!");
			
			ans=num1/num;
			System.out.println("My Answer processed");
			
		}
		
		catch (ArithmeticException | NumberFormatException | FileNotFoundException e) {
			System.out.println("Error Message:" + e.getMessage());
		}
		/*catch(CloneNotSupportedException e) {
			System.out.println("Error Message:" + e.getMessage());
		}
		*/
		catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Answer:" + ans);
		
		
		

	}

}
