package org.cap.demo;

import java.util.Scanner;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	public Shop getShopDetails() {
		Shop shop=new Shop();
		
		System.out.println("Enter Shop Id:");
		shop.setShopId(sc.nextInt());
		
		
		System.out.println("Enter Shop Name:");
		shop.setShopName(sc.next());
		
		System.out.println("Enter Shop Address:");
		shop.setShopAddress(sc.next());
		
		System.out.println("1.Saturday");
		System.out.println("2.Sunday");
		System.out.println("3.Monday");
		System.out.println("4.Tuesday");
		System.out.println("5.Wednesday");
		System.out.println("6.Thursday");
		System.out.println("7.Friday");
		System.out.println("Enter Your Holiday (1-7):");
		int choice=sc.nextInt();
		
		if(choice==1)
			shop.setHoliday(Holiday.SAT);
		else if(choice==2)
			shop.setHoliday(Holiday.SUN);
		else if(choice==3)
			shop.setHoliday(Holiday.MON);
		else if(choice==4)
			shop.setHoliday(Holiday.TUS);
		else if(choice==5)
			shop.setHoliday(Holiday.WED);
		else if(choice==6)
			shop.setHoliday(Holiday.THUR);
		else if(choice==7)
			shop.setHoliday(Holiday.FRI);
		
		return shop;
	}

}
