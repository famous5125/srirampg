package org.cap.demo;

public class MyThread extends Thread{

	
	public  MyThread() {
		
	}
	
	public  MyThread(String threadName) {
		super(threadName);
	}
	
	@Override
	public void run() {
		/*System.out.println("Thread Name:" + Thread.currentThread().getName()
				+"-->" + Thread.currentThread().getId());
		System.out.println("Thread Doing task!");*/
		int i=1;
		while(true) {
			System.out.println(i*10);
			i+=1;
		}
		
	}
	
	
}
