package org.cap.demo;

public class Table {
	
	
	public  void printTable(int num) {
		System.out.println("Table Started");
		
		synchronized (this) {
			for(int i=1;i<=10;i++)
				System.out.println(i+"*"+num+"="+(num*i));
		}
		
		System.out.println("Table Completed");
	}

}
