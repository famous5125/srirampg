package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println("Main Thread Name:" + Thread.currentThread().getName()
				+"-->" + Thread.currentThread().getId());
		
		MyThread t1=new MyThread();
		//t1.start();
		t1.run();

		MyThread t2=new MyThread("FirstThread");
		t2.start();
	}

}
