package org.cap.demo.interThrdComm;

public class Product {
	
	int quantity;
	
	public Product() {
		
	}
	
	public Product(int quantity) {
		this.quantity=quantity;
	}
	
	synchronized public void consume(int qty) {
		
		System.out.println("Before Consume product. Qty:" + this.quantity);
		
			
		if(this.quantity<qty) {
			try {
				System.out.println("Insufficient Quantity! Waiting..........");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		this.quantity-=qty;
		
		System.out.println("After Consuming Qty:" + this.quantity);
		
	}
	
	synchronized public void produce(int qty) {
		System.out.println("----------------------------------");
		System.out.println("Before produce. Qty:" + this.quantity);
		
		this.quantity+=qty;
			//notifyAll();
		notify();
		
		System.out.println("After produce. Qty:" + this.quantity);
	}

}
