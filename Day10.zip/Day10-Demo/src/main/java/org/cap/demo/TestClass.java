package org.cap.demo;

public class TestClass {

	public static void main(String[] args) {
	
		ThreadGroup group=new ThreadGroup("SPARK");
		
		RunnableThread runnable=new RunnableThread();
		Thread t1=new Thread(group,runnable);
		Thread t2=new Thread(group,runnable);
		Thread t3=new Thread(group,runnable);
		System.out.println("Count:---->" + group.activeCount());
		
		t1.start();
		System.out.println("Count:---->" + group.activeCount());
		t1.setPriority(10);
		System.out.println("Priority:" + t1.getPriority());
		
		/*try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		System.out.println("Count:---->" + group.activeCount());
		t2.start();
		t3.start();
		
		
		System.out.println("Count:---->" + group.activeCount());
		
		System.out.println("Priority:" + t2.getPriority());
		System.out.println("Priority:" + t3.getPriority());
		
		
		System.out.println("Count:---->" + group.activeCount());
		
		
	}

}
