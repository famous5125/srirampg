package org.cap.demo.interThrdComm;

public class MainClass {

	public static void main(String[] args) {
		
		final Product product=new Product(50);
		
		Thread t1=new Thread() {
			public void run() {
				product.consume(30);
			}
		};
		
		t1.start();
		
		
		Thread t2=new Thread() {
			public void run() {
				product.consume(30);
			}
		};
		t2.setPriority(10);
		t2.start();
		
		
		
		Thread t3=new Thread() {
			public void run() {
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				product.produce(20);
			}
		};
		
		t3.start();
		
		
		Thread t4=new Thread() {
			public void run() {
				product.consume(130);
			}
		};

		
		t4.start();
	}

}
