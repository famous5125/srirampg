package org.cap.demo;

public class DemoClass {

	public static void main(String[] args) {
		
		final Table table=new Table();
		
		
		Thread t1=new Thread() {
		
			public void run() {
				table.printTable(10);
			}
		};
		
		t1.start();
		
		
		Runnable runnable=new Runnable() {
			
			public void run() {
				table.printTable(11);
			}
		};
		Thread t2=new Thread(runnable);
		t2.start();
		
		
		Thread t3=new Thread() {
			
			public void run() {
				table.printTable(15);
			}
		};
		
		t3.start();
		

	}

}
