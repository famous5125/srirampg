package org.cap.demo;

public class Solution {

	public static void main(String[] args) {
		
		RunnableThread runnable=new RunnableThread();
		//Thread t1=new Thread(runnable);
		MyThread t1=new MyThread();
		Thread t2=new Thread(runnable);
		Thread t3=new Thread(runnable);
		
		//Thread.yield();
		t2.yield();
		
		t1.setDaemon(true);
		t1.start();t2.start();t3.start();
		
		
	}

}
