package org.cap.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Child  extends Parent{
	
	@Override
	public void show() throws Exception {
		
		/*File file=new File("sample.txt");
		FileInputStream fileInputStream=new FileInputStream(file);*/
		
		System.out.println("Hello! Child Method!");
		
		
	}
	
	public static void main(String[] args) throws Exception {
		Child child=new Child();
		child.show();
		try {
			Parent parent=new Parent();
			parent.show();
		}catch (ArithmeticException e) {
			e.printStackTrace();
		}
	}

}
