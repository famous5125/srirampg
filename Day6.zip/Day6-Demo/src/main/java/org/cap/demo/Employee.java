package org.cap.demo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee {
	int empId;
	String empName;
	Date emp_Date_of_joining;
	
	
	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.emp_Date_of_joining=new Date();
		
		//employee.emp_Date_of_joining=new Date(2000,12,21,23,45,12);
		
		//String myDate="12-mar-2000";
		//String myDate="11/11/2000";
		//employee.emp_Date_of_joining=new Date(myDate);
		
		System.out.println(employee.emp_Date_of_joining.getYear()+1900);
		System.out.println(employee.emp_Date_of_joining.getMonth());
		System.out.println(employee.emp_Date_of_joining.getTime());
		
		
		Date date=new Date(1518413281151L);
		System.out.println(date);
		
		
		SimpleDateFormat myformat=new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		System.out.println(myformat.format(date));
		
		
	}

}
