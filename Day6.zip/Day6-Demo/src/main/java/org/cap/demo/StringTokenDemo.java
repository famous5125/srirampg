package org.cap.demo;

import java.util.StringTokenizer;

public class StringTokenDemo {

	public static void main(String[] args) {
		
		//String str="Hello! I am working!";
		String str="Sam|Jack|Tom|Jerry";
		
		StringTokenizer tokenizer=new StringTokenizer(str, "|");
		
		int count=tokenizer.countTokens();
		
		
		System.out.println("Count:" + count);
		while(tokenizer.hasMoreElements()) {
			System.out.println(tokenizer.nextToken());
		}

		
		
	}

}
