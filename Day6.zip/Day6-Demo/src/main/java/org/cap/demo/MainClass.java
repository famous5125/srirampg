package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		int age=21;
		
			assert age>=18:"Age should be greater than 18!";
		
		System.out.println("Age: " + age);
		

	}

}
