package org.cap.demo;

public enum MyDays {
	
	//SUNDAY(1);

}
