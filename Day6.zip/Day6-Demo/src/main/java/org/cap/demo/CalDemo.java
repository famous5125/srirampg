package org.cap.demo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalDemo {

	public static void main(String[] args) {
		Calendar calendar=new GregorianCalendar(2000,1,12);
		
		System.out.println(calendar);
		System.out.println(calendar.get(Calendar.MONTH));
		System.out.println(calendar.get(Calendar.DATE));
		System.out.println(calendar.get(Calendar.YEAR));
		System.out.println(calendar.get(Calendar.WEEK_OF_MONTH));
		System.out.println(calendar.get(Calendar.WEEK_OF_YEAR));
		
		System.out.println(calendar.WEEK_OF_MONTH);
		System.out.println(calendar.MONTH);
		

		System.out.println(Calendar.WEEK_OF_MONTH);
		System.out.println(Calendar.MONTH);


	}

}
