package org.cap.demo;

import java.io.FileNotFoundException;

public class Parent {
	
	//public void show() throws ArithmeticException,FileNotFoundException{
	public void show() throws Exception{
		int num1=100;
		int num2=0;
		
		int ans=num1/num2;
		
		System.out.println("Answer:"  +ans);
		
	}

}
