package org.cap.demo;

public class TestClass {
	
	
	public static void main(String ... args) {
		
		if(args.length>0) {
			for(String str:args)
				System.out.println(str);
		}
		
		System.out.println("Program completed");
		
		
		main(23, 45);

	}

	
	public static void main(int num1,int num2) {
		
		
		System.out.println("Answer: " + num1+num2);

	}

	
}
