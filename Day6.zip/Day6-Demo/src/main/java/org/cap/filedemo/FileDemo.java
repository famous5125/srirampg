package org.cap.filedemo;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\greet1.txt");
		
		if(file.isDirectory()) {
			
			System.out.println("Hey! Its Directory.");
			
			String[] fileNames=file.list();
			for(String fileName:fileNames)
				System.out.println(fileName);
			
		}else if(file.isFile()) {
			System.out.println("Hey! Its File.");
			
			System.out.println("Readable:" + file.canRead());
			System.out.println("Writable:" + file.canWrite());
			System.out.println("Executable:" + file.canExecute());
			System.out.println("Last Modified:" + new Date(file.lastModified()));
			
			System.out.println("Size:" + file.length() + " bytes");
			System.out.println("Memory:" + file.getTotalSpace());
			System.out.println("FreeMemory:" + file.getFreeSpace());
			System.out.println("Used Memory:" + file.getUsableSpace());
			System.out.println("Used Memory:" + (file.getTotalSpace() - file.getFreeSpace()));
			
			System.out.println("Path:" + file.getPath());
			System.out.println("Path:" + file.getAbsolutePath());
			System.out.println("Parent Directory:" + file.getParent());
			
		}else {
			System.out.println("Hey! Create new File");
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
