package org.cap.filedemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharReadDemo {

	public static void main(String[] args) {
		
		CharReadDemo demo=new CharReadDemo();
		demo.writeData();
		
	}
	
	public void readData() {
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\greet.txt");
		FileReader fileReader=null;
			try {
			fileReader=new FileReader(file);
			
			int chr=fileReader.read();
				while(chr!=-1) {
					System.out.print((char)chr);
					chr=fileReader.read();
				}
			}catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally {
				try {
					fileReader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

	}
	
	
	public void writeData() {
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\greet1.txt");
		
		FileWriter fileWriter=null;
		try {
			 
			String str="Hello World!";
			fileWriter=new FileWriter(file);
			
			fileWriter.write(str);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
