package com.capgemini.tags;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyTagHandler extends SimpleTagSupport {
	
	private String userName;
	
	

	public void setUserName(String userName) {
		this.userName = userName;
	}



	@Override
	public void doTag() throws JspException, IOException {
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		
		JspWriter out= getJspContext().getOut();
		if(userName!=null)
		{
		out.println("<h1>Hello!" + str +". "+ userName +"</h1>");
		}else
			out.println("<h1>Hello!" + str +".</h1>");
	}

	
	
}
