package org.cap.demo;

public class CircleOnRectangle extends Circle {

	@Override
	public void calculate(float radius){
		
	}
}
