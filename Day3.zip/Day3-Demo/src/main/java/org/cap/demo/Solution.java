package org.cap.demo;

public class Solution {

	public void sortString(int num,String ... names) {
		for(String name:names) {
			System.out.println(name);
		}
	}
	
	public static void main(String[] args) {
		Solution obj=new Solution();
		String[] strs= {"one","two","three"};
		
		obj.sortString(1,"Tom","Jerry","Sam");
		obj.sortString(10,strs);
	}
	
}
