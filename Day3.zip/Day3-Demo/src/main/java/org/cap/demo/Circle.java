package org.cap.demo;

public class Circle{

	final float pi=3.14f;
	
	
	public  void calculate(final float radius){
		final float area;
		//float pi=8.3f;
		
		//pi=34.56f;
		
		//radius+=5;
		
		area=this.pi*radius*radius;
		//area=100.0f;
		System.out.println("Area:" + area);
	}

	
	public static void main(String[] args) {
		Circle circle=new Circle();
		circle.calculate(45.2f);
		circle.calculate(5.2f);
	}

}