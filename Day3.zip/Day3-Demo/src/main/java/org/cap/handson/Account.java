package org.cap.handson;

public class Account {
	
	private int aacountId;
	private String accountName;
	private Address address;
	private double depositAmount;
	
	public Account() {
		
	}
	
	
	public Account(int aacountId, String accountName, Address address, double depositAmount) {
		super();
		this.aacountId = aacountId;
		this.accountName = accountName;
		this.address = address;
		this.depositAmount = depositAmount;
	}
	
	
	

	public int getAacountId() {
		return aacountId;
	}


	public void setAacountId(int aacountId) {
		this.aacountId = aacountId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	public double getDepositAmount() {
		return depositAmount;
	}


	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}


	public void getDetails() {
		
	}

	public void showDetails() {
		
	}


	@Override
	public String toString() {
		return "Account [aacountId=" + aacountId + ", accountName=" + accountName + ", address=" + address
				+ ", depositAmount=" + depositAmount + "]";
	}
	
	
	
}
