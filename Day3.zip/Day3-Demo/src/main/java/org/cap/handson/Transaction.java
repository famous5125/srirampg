package org.cap.handson;

public class Transaction extends Loan {
	
	private double amount;
	
	public Transaction(int aacountId,String accountName,
			Address address,double depositAmount) {
		super(aacountId,accountName,address,depositAmount);
	}
	
	
	public Transaction(int aacountId,String accountName,
			Address address,double depositAmount,int loanId, 
			LoanType loanType,double loanAmount) {
		super(aacountId,accountName,address,depositAmount,loanId,loanType,loanAmount);
	}
	
	
	
	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public void depositAmount() {
		
	}

	
	public void withdrawAmount() {
		
	}
	
	public void payLoan() {
		
	}
	public void showAccountDetails() {
		
	}


	@Override
	public String toString() {
		return "Transaction [amount=" + amount + "]";
	}
	
	
	

}
