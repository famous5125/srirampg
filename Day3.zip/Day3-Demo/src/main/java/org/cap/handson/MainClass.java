package org.cap.handson;

import org.cap.handson.Loan.LoanType;

public class MainClass {

	public static void main(String[] args) {
		Transaction[] transactions= getAllAccounts();
		
		for(Transaction transaction:transactions) {
			System.out.println(
					"AccountNo:" + transaction.getAacountId() + "  "+
					"AccountName:" +transaction.getAccountName()+ "  "+
					"DepositAmount" + transaction.getDepositAmount()+ "  "+
					"Loan Id:" + transaction.getLoanId() + "  "+
					"Loan TYpe:" + transaction.getLoanType() + "  "+
					"Loan Amount: " + transaction.getLoanAmount()+ "  "+
					"Transaction Amount:" + transaction.getAmount());
		}

	}
	
	
	public static Transaction[] getAllAccounts() {
		Transaction[] transactions=new Transaction[10];
		
		Address address=new Address("23/A", "north Avvenue", "Chennai", "TN", "620047");
		transactions[0]=new Transaction(1001,"Tom",address,15000,1,LoanType.HOME,10000000);
		
		Address address1=new Address("22/A", "South Avvenue", "Chennai", "TN", "62809809");
		transactions[1]=new Transaction(1002,"Jerry",address1,20000,1,LoanType.CAR,100000);
		
		
		
		return transactions;
	}

}
