package org.cap.handson;

public class Loan extends Account {
	
	public enum LoanType{
		HOME,CAR,EDUCATION,AGRICULTUR;
	}

	private int loanId;
	private LoanType loanType;
	private double loanAmount;
	
	public Loan() {
		
	}
	
	public Loan(int aacountId,String accountName,
			Address address,double depositAmount) {
		super(aacountId,accountName,address,depositAmount);
	}
	
	public Loan(int aacountId,String accountName,
			Address address,double depositAmount,
			int loanId, LoanType loanType, double loanAmount) {
		
		super(aacountId,accountName,address,depositAmount);
		this.loanId=loanId;
		this.loanType=loanType;
		this.loanAmount=loanAmount;
	}
	
	public Loan(int loanId, LoanType loanType, double loanAmount) {
		super();
		this.loanId = loanId;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
	}

	
	
	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public void getLoan() {
		
	}
	
	public void showLoanDetails() {
		
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanType=" + loanType + ", loanAmount=" + loanAmount + "]";
	}
	
	
	
}
