package org.cap.interfacedemo;

public class MainClass {

	public static void main(String[] args) {
		
		Shape shape=new Circle();
		//Color color1=new Circle();
		
		/*Animation animation=new Triangle();
		Shape shape2=new Triangle();
		Color color=new Triangle();
		
		shape.draw();
		shape2.draw();*/
		
		
		Shape.print();
		
		Circle.print();
		
		
	}

}
