package org.cap.interfacedemo;

public class Circle implements Shape,Color{

	public void draw() {
		System.out.println("Draw Circle");
		
	}

	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	public void drawColor() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void show() {
		System.out.println("Circle Class-Show Method");
	}
	
	
	public static void print() {
		System.out.println("Circle Class-Print Method");
	}

}
