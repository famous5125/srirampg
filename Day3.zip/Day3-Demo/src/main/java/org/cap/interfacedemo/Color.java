package org.cap.interfacedemo;

public interface Color {
	
	void fillColor();
	void drawColor();

}
