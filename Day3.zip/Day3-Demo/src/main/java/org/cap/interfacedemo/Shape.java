package org.cap.interfacedemo;

public interface Shape {

	//Constant
	//public static final float pi=3.14f;
	float pi=3.14f;
	
	//abstract public void draw();
	
	void draw();
	
	
	default void show() {
		System.out.println("Shape interface-Show Method");
	}
	
	public static void print() {
		System.out.println("Shape interface-Print Method");
	}
	
	
}
