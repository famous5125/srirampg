package org.cap.interfacedemo;

public interface Animation extends Shape,Color {
	
	void move();
	void  drag();

}
