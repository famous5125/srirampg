package org.cap.interfacedemo;

public class Triangle implements Animation{

	public void draw() {
		System.out.println("Draw TRiangle");
		
	}

	public void move() {
		// TODO Auto-generated method stub
		
	}

	public void drag() {
		// TODO Auto-generated method stub
		
	}

	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	public void drawColor() {
		// TODO Auto-generated method stub
		
	}

}
