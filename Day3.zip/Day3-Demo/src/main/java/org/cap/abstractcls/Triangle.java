package org.cap.abstractcls;

public class Triangle extends Shape{

	
	
	public Triangle() {
		System.out.println("No args Constructor- Triangle");
	}
	
	@Override
	public void draw() {
		System.out.println("Draw Triangle");
		
	}

}
