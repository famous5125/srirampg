package org.cap.abstractcls;

public class MainClass {

	public static void main(String[] args) {
		Shape shape;
		
		shape=new Circle(4.5f);
		shape.draw();
		//shape.circleInfo();
		shape=new Triangle();
		shape.draw();
	}

}
