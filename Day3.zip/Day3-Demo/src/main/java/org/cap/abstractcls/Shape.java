package org.cap.abstractcls;

abstract public class Shape {
	
	float points;
	private final float pi=3.14f; 
	
	
	public Shape() {
		System.out.println("No args Constructor- Shape");
	}
	
	
	public Shape(float points) {
		this.points=points;
		System.out.println("Overloaded constructor - Shape: " + this.points);
	}
	
	abstract public void draw();
	
	//Non - Abstarct
	public void shapeInfo() {
		System.out.println("Shape Details");
	}

}
