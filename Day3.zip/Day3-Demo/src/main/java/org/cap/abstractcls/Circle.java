package org.cap.abstractcls;

public class Circle extends Shape{

	
	public Circle() {
		System.out.println("No args Constructor- Circle");
	}
	
	public Circle(float points) {
		super(points);
		System.out.println("Overloaded constructor - Circle");
	}
	
	
	@Override
	public void draw() {
		System.out.println("Draw Circle");
		
	}

	public void circleInfo() {
		System.out.println(" Circle Info");
	}

}
