package org.cap.demo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectIODemo {

	public static void main(String[] args) {
		//writeProductObject();
		readProductObject() ;
	}
	
	
	public static void writeProductObject() {
		Product product=new Product(123, "Lux", 56, 90, false);
		Product product1=new Product(133, "Cintol", 78, 34.67, true);
		Product product2=new Product(678, "Medimix", 12,45.7, false);
		
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\filedemo\\product.dat");
		
		FileOutputStream outputStream=null;
		ObjectOutputStream objectOutputStream=null;
		try {
			outputStream=new FileOutputStream(file);
			objectOutputStream=new ObjectOutputStream(outputStream);
			
			objectOutputStream.writeObject(product);
			objectOutputStream.writeObject(product1);
			objectOutputStream.writeObject(product2);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				outputStream.close();
				objectOutputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	public static void readProductObject() {
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\filedemo\\product.dat");
		
		
		FileInputStream fileInputStream=null;
		ObjectInputStream objectInputStream=null;
		
		try {
			fileInputStream=new FileInputStream(file);
			objectInputStream=new ObjectInputStream(fileInputStream);
			Product product=null;
			do {
				product=(Product)objectInputStream.readObject();
			
				System.out.println(product);
			}while(product!=null);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (EOFException e) {
			
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fileInputStream.close();
				objectInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
