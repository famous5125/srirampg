package org.cap.demo;

import java.util.ArrayList;

public class MethodsInArrayLst {

	public static void main(String[] args) {
		
		ArrayList<String> list=new ArrayList<>();
		list.add("Tom");
		list.add("Jack");
		list.add("Jack");
		list.add("Thomson");
		list.add("Emi");
		list.add("Clera");
		list.add(null);
		list.add("Jessi");
		list.add("Clera");
		list.add(null);
		list.add("Chin");
		
		
		ArrayList<String> mylist=new ArrayList<>();
		mylist.add("A");
		mylist.add("B");
		mylist.add("C");
		
		list.addAll(mylist);
		
		
		//list.add("Sasi");
 		System.out.println(list);
 		System.out.println("Size:" + list.size());
 		
 		String str="Jack1";
 		System.out.println(list.contains(str));
 		
 		/*list.clear();*/
 		System.out.println(list);
 		System.out.println(list.isEmpty());
 		
 		list.ensureCapacity(100);
 	
 		
	}

}
