package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;



public class Demo {

	public static void main(String[] args) {
		//List<String> list=new ArrayList<>();
		ArrayList<String> list=new ArrayList<String>();
		//Collection<String> list=new ArrayList<>();
		//Iterable<String> list=new ArrayList<>();
		
		
		//list.
		
		list.add("Tom");
		list.add("Jerry");
		list.add(null);
		/*list.add(90);
		list.add(7.8f);*/
		list.add("Jerry");
		list.add("Jerry");
		list.add("Jack");
		
		System.out.println(list);
		
		//Enhanced For loop
		for(String str:list)
			System.out.print(str + "-->");
		System.out.println("");
		
		
		//Iterator
		Iterator<String> iterator= list.iterator();
		while(iterator.hasNext()) {
			String str=iterator.next();
			if(str==null)
				iterator.remove();
			System.out.println(str);
		}
		
		
		System.out.println(list);
		
		
		//list iteration
		ListIterator<String> listIterator=list.listIterator();
		while(listIterator.hasNext()) {
			String myData=listIterator.next();
			if(myData.equals("Tom"))
				//listIterator.remove();
				listIterator.set("Kamal");
			System.out.print(myData+"--->");
		}
		
		System.out.println("");
		
		while(listIterator.hasPrevious())
			System.out.print(listIterator.previous()+"--->");
	}

}
