package org.cap.demo;

import java.util.ArrayList;
import java.util.List;

public class CollectionDemo {

	public static void main(String[] args) {
		//ArrayList mylist=new ArrayList();
		List mylist=new ArrayList();
		mylist.add(null);
		mylist.add("Tom");
		mylist.add(null);
		mylist.add("Jerry");
		mylist.add(23);
		mylist.add(7.8f);
		mylist.add("Jerry");
		mylist.add("Jerry");
		mylist.add(true);
		mylist.add(false);
		mylist.add(20000.0);
		mylist.add('c');
		mylist.add('c');
		mylist.add(null);
		mylist.add(20000.0);
		mylist.add(20000.0);
		mylist.add(null);

		System.out.println(mylist);
	}

}
