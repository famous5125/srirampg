package org.cap.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FormattedIODemo {

	public static void main(String[] args) {
		//writeData();
		readData();

	}
	
	
	public static void writeData() {
		int empId=1001;
		double salary=2000;
		boolean isPermenant=true;
		String empName="Tom";
		
		
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\filedemo\\employee.txt");
		
		FileOutputStream out=null;
		DataOutputStream dataOutputStream=null;
		try {
			out = new FileOutputStream(file);
			dataOutputStream=new DataOutputStream(out);
			
				dataOutputStream.writeInt(empId);
				dataOutputStream.writeDouble(salary);
				dataOutputStream.writeBoolean(isPermenant);
				dataOutputStream.writeBytes(empName);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
				try {
					out.close();
					dataOutputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
		}
	
		
	}
	
	
	
	public static void readData() {
		
		File file=new File("D:\\vidavid\\Training\\2018\\JAVA_5_Feb_to_16_Feb\\filedemo\\employee.txt");
	
		FileInputStream inputStream=null;
		DataInputStream dataInputStream=null;
		
		try {
			inputStream=new FileInputStream(file);
			dataInputStream=new DataInputStream(inputStream);
			
			int employeeId=dataInputStream.readInt();
			double salary=dataInputStream.readDouble();
			boolean isPermanent=dataInputStream.readBoolean();
			
			byte[] empName=new byte[3];
			dataInputStream.read(empName);
			
			System.out.println("EmployeeName:");
			for(byte empNameChar:empName)
				System.out.print((char)empNameChar);
			
			System.out.println("");
			System.out.println("EmployeeId:" + employeeId);
			System.out.println("Salary:" + salary);
			System.out.println("Is Premanent:" + isPermanent);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (EOFException e) {
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			
		}finally {
			try {
				inputStream.close();
				dataInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	

}
