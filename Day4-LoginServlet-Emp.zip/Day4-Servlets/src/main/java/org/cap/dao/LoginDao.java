package org.cap.dao;

import org.cap.pojo.LoginPojo;

public interface LoginDao {
	public boolean validateLogin(LoginPojo login);
}
