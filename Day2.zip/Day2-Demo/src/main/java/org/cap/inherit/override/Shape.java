package org.cap.inherit.override;

public class Shape {
	
	int points;
	
	public void draw() {
		System.out.println("Draw Shape");
	}
	
	public void shapeInfo() {
		System.out.println("Shape Information");
	}

}
