package org.cap.inherit.override;

public class Circle extends Shape {
	
	double radius;
	
	@Override
	public void draw() {
		System.out.println("Draw Shape - Circle");
	}
	
	public void circleInfo() {
		System.out.println("Circle drawn for the given radius");
	}

}
