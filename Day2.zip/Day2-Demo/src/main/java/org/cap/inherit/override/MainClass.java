package org.cap.inherit.override;

public class MainClass {

	public static void main(String[] args) {
		//Circle circle=new Circle();
		Shape circle;
		int myChoice=2;
		if(myChoice==1)
			circle=new Circle();
		else
			circle=new Shape();
		
		circle.draw();
	//	circle.circleInfo();
		circle.shapeInfo();
	}

}
