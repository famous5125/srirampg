package org.cap.inherit;

import java.util.Scanner;

public class Marks extends Person{
	
	int mark1,mark2,mark3;
	
	public Marks() {
		System.out.println("Marks class Constructor");
	}
	
	public Marks(int mark1,int mark2,int mark3, String firstName,String lastName) {
		
		super(firstName,lastName);
		this.mark1=mark1;

		this.mark2=mark2;
		this.mark3=mark3;
	}
	
	
	public void getMarkDetails() {
		Scanner sc=new Scanner(System.in);
		
		//this.firstName="Tom";
		
		getPersonDetails();
		
		System.out.println("Enter 3 makrs:");
		this.mark1=sc.nextInt();
		this.mark2=sc.nextInt();
		this.mark3=sc.nextInt();
	}
	
	public void showMarkDetails() {
		
		showPersonDetails();
		super.display();
		System.out.println("Mark1: "+this.mark1 +
				"\nMark2:" + this.mark2
				+"\nMark3:" + this.mark3);
	}
	
	
	@Override
	public void display() {
		System.out.println("Marks -> Display method");
	}
	
 
}
