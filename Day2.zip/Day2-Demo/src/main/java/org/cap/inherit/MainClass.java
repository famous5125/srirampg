package org.cap.inherit;

public class MainClass {

	public static void main(String[] args) {
		
		/*Marks marks=new Marks();
		//Person marks=new Marks();
		marks.getPersonDetails();
		marks.getMarkDetails();
		marks.showPersonDetails();
		marks.showMarkDetails();*/
		
		Student student=new Student();
		student.getStudentDetails();
		student.showStudentDetails();

	}

}
