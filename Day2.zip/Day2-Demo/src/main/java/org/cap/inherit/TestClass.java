package org.cap.inherit;

public class TestClass {

	public static void main(String[] args) {
		Marks marks=new Marks(12,34,54,"Tom","Jerry");
		//marks.getMarkDetails();
		marks.showMarkDetails();
		
		
	}

}
