package org.cap.inherit;

import java.util.Scanner;

public class Student extends Marks{
	
	private String schoolName;
	private int schoolId;
	
	public void getStudentDetails() {
		getPersonDetails();
		getMarkDetails();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter SchoolId:");
		this.schoolId=sc.nextInt();
		
		System.out.println("Enter School Name:");
		this.schoolName=sc.next();
		
	}
	
	public void showStudentDetails() {
		
		showPersonDetails();
		showMarkDetails();
		System.out.println("School ID:" + this.schoolId);
		System.out.println("School Name:" + this.schoolName);
	}

}
