package org.cap.inherit;

import java.util.Scanner;

public class Person {
	
	private String firstName;
	private String lastName;
	private int personId;
	private String address;
	
	
	public Person() {
		System.out.println("Person class Constructor");
	}
	
	
	
	
	
	public Person(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}





	public Person(String firstName, String lastName, int personId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.personId = personId;
	}





	public Person(String firstName, String lastName, int personId, String address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.personId = personId;
		this.address = address;
	}




	public void getPersonDetails() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter PersonId:");
		this.personId=sc.nextInt();
		
		System.out.println("Enter FirstName:");
		this.firstName=sc.next();
		
		System.out.println("Enter LastName:");
		this.lastName=sc.next();
		
		System.out.println("Enter Address:");
		this.address=sc.next();
	}

	
	
	protected void showPersonDetails() {
		System.out.println("Person Id:" + this.personId);
		System.out.println("FirstName:" + this.firstName);
		System.out.println("LastName:" + this.lastName);
		System.out.println("Address:" + this.address);
		
	}
	
	
	public void display() {
		System.out.println("Person -> Display method");
	}
	
	
	
	
	
}
