package org.cap.sample;

public class Demo {

	public static void main(String[] args) {
		Rectangle rect=new Rectangle();
		rect.setHeight(3.5);
		rect.setWidth(7.8);
		
		System.out.println("Height:" +rect.getHeight() );
		System.out.println("Width:" +rect.getWidth() );
	}

}
