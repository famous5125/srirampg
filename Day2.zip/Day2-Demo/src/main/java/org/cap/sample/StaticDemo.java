package org.cap.sample;

public class StaticDemo {
	
	
	int num=10;
	static int count=0;

	public void display() {

		System.out.println("Number:" + num++);
		System.out.println("Count:" + count++);
	}
	
	
	public static void main(String[] args) {
		
		StaticDemo obj=new StaticDemo();
		obj.display();
		obj.display();
		
		StaticDemo obj1=new StaticDemo();
		obj1.display();
	}

}
