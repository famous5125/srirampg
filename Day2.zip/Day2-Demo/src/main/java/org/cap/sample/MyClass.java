package org.cap.sample;
import static org.cap.demo.Demo.*;


public class MyClass {

	public static void main(String[] args) {
	
		//Demo obj=new Demo();
		//obj.display();
		
		show();
		
	}

}
