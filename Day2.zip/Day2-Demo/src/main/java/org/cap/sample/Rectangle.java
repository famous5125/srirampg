package org.cap.sample;

public class Rectangle {
	
	private double height;
	private double width;
	
	public Rectangle() {
		
	}
	
	//getter
	public double getHeight() {
		return this.height;
	}
	
	//setter
	public void setHeight(double height) {
		this.height=height;
	}
	
		//getter
		public double getWidth() {
			return this.width;
		}
		
		//setter
		public void setWidth(double width) {
			this.width=width;
		}

}
