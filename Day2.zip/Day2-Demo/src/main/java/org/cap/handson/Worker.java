package org.cap.handson;

import java.util.Scanner;

public class Worker {
	
	String name;
	double salaryRate;
	
	public void getName() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		this.name=sc.next();
	}
	
	public double computePay(int hours) {
				
		return salaryRate*hours;
	}

}
