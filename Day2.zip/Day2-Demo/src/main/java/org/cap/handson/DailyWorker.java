package org.cap.handson;

import java.util.Scanner;

public class DailyWorker extends Worker{
	
	@Override
	public double computePay(int hours) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("DailyWorker Wages Compute:");
		System.out.println("Enter wages per hour:");
		salaryRate=sc.nextDouble();
		return salaryRate*hours;
	}
	
}
