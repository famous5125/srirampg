package org.cap.handson;

import java.util.Scanner;

public class SalariedWorker extends Worker{
	
	@Override
	public double computePay(int days) {
		System.out.println("SalariedWorker Salary Compute:");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary per day:");
		salaryRate=sc.nextDouble();
		return salaryRate*days;
	}
}
