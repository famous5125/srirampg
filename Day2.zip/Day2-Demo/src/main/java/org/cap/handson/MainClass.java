package org.cap.handson;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		int choice;
		Worker worker;
		int hours;
		double salary;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Daily Workers");
		System.out.println("2.Salaried Workers");
		System.out.println("Enter Your Choice:");
		choice=sc.nextInt();
		
		if(choice==1) {
			worker=new DailyWorker();
			worker.getName();
			System.out.println("Enter no of Hours Worked:");
			hours=sc.nextInt();
			
			salary=worker.computePay(hours);
			System.out.println("Name: " + worker.name);
			System.out.println("Wages: " + salary);
			
		}else {
			worker=new SalariedWorker();
			worker.getName();
			System.out.println("Enter no of Days:");
			hours=sc.nextInt();
			
			salary=worker.computePay(hours);
			
			System.out.println("Name: " + worker.name);
			System.out.println("Salary: " + salary);
		}
	}

}
