package org.cap.demo;

public class Demo {

	//instance member
	int num=100;//--->3
	

	{
		System.out.println("Static Block:" + count);
		System.out.println("Normal Block:" +num);
	}
	
	
	//static member --> 1
	static int count=90;
	
	static {//---->2
		
		System.out.println("Static Block:" + count);
		
		
		//System.out.println("Number:" + num);
	}
	
	
	public Demo() {//---->4
		System.out.println("My No Arg Constructor");
	}
	
	//instance Method
	public void display() {
		System.out.println("Number :" + num);
		System.out.println("Count :" + count);
	}
	
	//Static Method
	public static void show() {
		System.out.println("Static Method");
		//System.out.println("Number :" + num);
		System.out.println("Count :" + count);
	}
	
	public static void main(String[] args) {
		Demo obj=new Demo();
		obj.display();
		
		Demo obj1=new Demo();
		
		show();
		show();
	}

}
