package org.cap.demo;

public class MyClass {

	public static void main(String[] args) {
	
		
		Demo.show();

	}

}
