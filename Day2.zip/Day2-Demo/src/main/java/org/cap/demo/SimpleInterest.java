package org.cap.demo;

public class SimpleInterest {
	
	double principle;
	double interest_rate;
	double years;
	
	
	public SimpleInterest() {
		this.principle=5000.0;
		this.interest_rate=0.50;
		this.years=3;
	}
	
	
	public double calculate_SI() {
		return this.principle*this.interest_rate*this.years;
	}
	
	public double calculate_SI(double principle) {
		this.principle=principle;
		return this.principle*this.interest_rate*this.years;
	}
	
	
	/*public void calculate_SI(double principle) {
		this.principle=principle;
		return this.principle*this.interest_rate*this.years;
	}*/
	
	
	public void calculate_SI(double principle,String str) {
		this.principle=principle;
		//return this.principle*this.interest_rate*this.years;
	}
	
	public void calculate_SI(String str,double principle) {
		this.principle=principle;
		//return this.principle*this.interest_rate*this.years;
	}
	
	public double calculate_SI(double principle,double interest_rate) {
		//this.principle=principle;
		//this.interest_rate=interest_rate;
		return this.principle*this.interest_rate*this.years;
	}
	
	
	

	public double calculate_SI(double principle,double interest_rate,double years) {
		this.principle=principle;
		this.interest_rate=interest_rate;
		this.years=years;
		return this.principle*this.interest_rate*this.years;
	}
	
	public static void main(String[] args) {
		SimpleInterest si=new SimpleInterest();
		double amount=si.calculate_SI();
		System.out.println("Simple Interest:" + amount);
		
		
		double amount1=si.calculate_SI(34000);
		System.out.println("Simple Interest:" + amount1);
		
		double amount2=si.calculate_SI(34000,.60);
		System.out.println("Simple Interest:" + amount2);
		
		double amount3=si.calculate_SI(34000,0.45,5);
		System.out.println("Simple Interest:" + amount3);
		
		
		
	}

}
