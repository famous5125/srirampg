package org.cap.demo;


public class Rectangle {
	
	double height,width;
	//double width;
	
	
	public Rectangle() {
		this.height=45.34;
		this.width=3.5;
		//if(this.height>0)
			System.out.println("No Argument Constructor");
	}
	
	//Overloaded Constructor
	public Rectangle(double height) {
		this.height=height;
		this.width=3.5;
		//if(this.height>0)
			System.out.println("ONe Argument Constructor");
	}
	public Rectangle(double height,double width) {
		this.height=height;
		this.width=width;
		//if(this.height>0)
			System.out.println("Two Argument Constructor");
	}
	
	
	public static void main(String[] args) {
		Rectangle rect=new Rectangle();
		
		System.out.println("Height:" + rect.height);
		System.out.println("Width:" + rect.width);
		
		Rectangle rect1=new Rectangle(3.57);
		System.out.println("Height:" + rect1.height);
		System.out.println("Width:" + rect1.width);
		
		
		Rectangle rect2=new Rectangle(3.57,5.7);
		System.out.println("Height:" + rect2.height);
		System.out.println("Width:" + rect2.width);
		
	}
	

}
