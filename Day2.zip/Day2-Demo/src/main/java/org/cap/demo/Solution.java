package org.cap.demo;

import java.util.Scanner;

public class Solution {
	  private static void printPascal(){
		    
		    
		    int i, j, k, number = 1;
		    Scanner scan = new Scanner(System.in);
		    System.out.print("Enter Number of Rows : ");
		    int r = scan.nextInt();
		    
		     for(i=0;i<r;i++)
		    {
		      for(k=r; k>i; k--)
		      {
		        System.out.print(" ");
		      }
		            number = 1;
		      for(j=0;j<=i;j++)
		      {
		         System.out.print(number+ " ");
		                 number = number * (i - j) / (j + 1);
		      }
		      System.out.println();
		    } 
		  }
		  
		  private static void isPowerOf5(){
		   // System.out.println("Sorry we have not implemented yet");
		    Scanner scan = new Scanner(System.in);
		    System.out.print("Enter a Number : ");
		    int n = scan.nextInt();
		    boolean isValid = true;
		    int res = n;
		    
		    if(res < 0){
		      System.out.print("please Enter a +ve number : ");
		      return;
		    }
		    
		    while(res >1 ) {
		      int mod = res % 5;
		      res = res / 5;
		      //2
		     // System.out.print("mod = "+mod+",res = "+res+"isValid = "+isValid);
		      if( mod != 0){
		        isValid = false;
		        break;
		      }
		        
		    }
		    
		    System.out.print(""+n+" is "+isValid);
		  }
		  
		  public static void main(String[] args) {
		    
		   int input;
		    Scanner scan = new Scanner(System.in);
		    
		    
		    
		    while(true){
		      System.out.print("\nEnter 1 for pascal triangle and 2 for power of 5 and any time to get out please enter 9");
		    input = scan.nextInt();
		      switch(input){
		        case 1: printPascal();
		              break;
		        case 2: isPowerOf5();
		              break;
		        case 9: System.exit(0);
		                break;
		        default: System.out.print("you have entered wrong code. try again... ");
		                break;
		      }
		    }    
		       
		  }

}
